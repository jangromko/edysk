/*************************************************************************
 *  Kompilacja:  javac FlowEdge.java
 *  Wykonanie:    java FlowEdge
 *
 *  Kraw�dzie o okre�lonej pojemno�ci i przep�ywie w sieci przep�ywowej.
 *
 *************************************************************************/

/**
 *  Klasa <tt>FlowEdge</tt> reprezentuje kraw�d� digrafu, maj�c� okre�lon� pojemno�� i 
 *  pewien przep�yw.
 *  <p>
 *  Dodatkow� dokumentacj� znajdziesz w <a href="/algs4/74or">podrozdziale 7.4</a> ksi��ki
 *  <i>Algorytmy, wydanie czwarte</i> Roberta Sedgewicka i Kevina Wayne'a.
 */


public class FlowEdge {
    private final int v;             // Wyj�ciowy wierzcho�ek
    private final int w;             // Docelowy wierzcho�ek
    private final double capacity;   // Pojemno��
    private double flow;             // Przep�yw

    public FlowEdge(int v, int w, double capacity) {
        if (capacity < 0) throw new RuntimeException("Ujemna pojemno�� kraw�dzi");
        this.v         = v;
        this.w         = w;  
        this.capacity  = capacity;
        this.flow      = 0;
    }

    public FlowEdge(int v, int w, double capacity, double flow) {
        if (capacity < 0) throw new RuntimeException("Ujemna pojemno�� kraw�dzi");
        this.v         = v;
        this.w         = w;  
        this.capacity  = capacity;
        this.flow      = flow;
    }

    // Metody dost�pu
    public int from()         { return v;        }  
    public int to()           { return w;        }  
    public double capacity()  { return capacity; }
    public double flow()      { return flow;     }


    public int other(int vertex) {
        if      (vertex == v) return w;
        else if (vertex == w) return v;
        else throw new RuntimeException("Niedozwolony punkt ko�cowy");
    }

    public double residualCapacityTo(int vertex) {
        if      (vertex == v) return flow;
        else if (vertex == w) return capacity - flow;
        else throw new RuntimeException("Niedozwolony punkt ko�cowy");
    }

    public void addResidualFlowTo(int vertex, double delta) {
        if      (vertex == v) flow -= delta;
        else if (vertex == w) flow += delta;
        else throw new RuntimeException("Niedozwolony punkt ko�cowy");
    }


    public String toString() {
        return v + "->" + w + " " + flow + "/" + capacity;
    }


   /**
     * Klient testowy.
     */
    public static void main(String[] args) {
        FlowEdge e = new FlowEdge(12, 23, 3.14);
        StdOut.println(e);
    }

}
