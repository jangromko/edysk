/*************************************************************************
 *  Kompilacja:  javac FlowNetwork.java
 *  Wykonanie:    java FlowNetwork V E
 *  Zale�no�ci: Bag.java FlowEdge.java
 *
 *  Sie� przep�ywowa z pojemno�ciami kraw�dzi, zaimplementowana za pomoc� 
 *  list s�siedztwa.
 *
 *************************************************************************/

public class FlowNetwork {
    private final int V;
    private int E;
    private Bag<FlowEdge>[] adj;
    
    // Pusty graf o V wierzcho�kach
    public FlowNetwork(int V) {
        this.V = V;
        this.E = 0;
        adj = (Bag<FlowEdge>[]) new Bag[V];
        for (int v = 0; v < V; v++)
            adj[v] = new Bag<FlowEdge>();
    }

    // Losowy graf o V wierzcho�kach i E kraw�dziach
    public FlowNetwork(int V, int E) {
        this(V);
        for (int i = 0; i < E; i++) {
            int v = StdRandom.uniform(V);
            int w = StdRandom.uniform(V);
            double capacity = StdRandom.uniform(100);
            addEdge(new FlowEdge(v, w, capacity));
        }
    }

    // Graf wczytywany ze strumienia wej�ciowego
    public FlowNetwork(In in) {
        this(in.readInt());
        int E = in.readInt();
        for (int i = 0; i < E; i++) {
            int v = in.readInt();
            int w = in.readInt();
            double capacity = in.readDouble();
            addEdge(new FlowEdge(v, w, capacity));
        }
    }

    // Liczba wierzcho�k�w i kraw�dzi
    public int V() { return V; }
    public int E() { return E; }

    // Dodawanie kraw�dzi e na listach s�siedztwa wierzcho�k�w v i w
    public void addEdge(FlowEdge e) {
        E++;
        int v = e.from();
        int w = e.to();
        adj[v].add(e);
        adj[w].add(e);
    }

    // Zwracanie listy kraw�dzi incydentnych do v
    public Iterable<FlowEdge> adj(int v) {
        return adj[v];
    }

    // Zwracanie listy wszystkich kraw�dzi
    public Iterable<FlowEdge> edges() {
        Bag<FlowEdge> list = new Bag<FlowEdge>();
        for (int v = 0; v < V; v++)
            for (FlowEdge e : adj(v))
                list.add(e);
        return list;
    }

    // �a�cuch znak�w reprezentuj�cy graf - metoda dzia�a w czasie kwadratowym
    public String toString() {
        String NEWLINE = System.getProperty("line.separator");
        StringBuilder s = new StringBuilder();
        s.append(V + " " + E + NEWLINE);
        for (int v = 0; v < V; v++) {
            s.append(v + ":  ");
            for (FlowEdge e : adj[v]) {
                s.append(e + "  ");
            }
            s.append(NEWLINE);
        }
        return s.toString();
    }

    // Klient testowy
    public static void main(String[] args) {
        int V = Integer.parseInt(args[0]);
        int E = Integer.parseInt(args[1]);
        FlowNetwork G = new FlowNetwork(V, E);

        StdOut.println(G);
    }
}
